package com.fooddelivery.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.fooddelivery.model.Food;
import com.fooddelivery.model.OrderFood;

@Repository("foodDao")
public class FoodDaoImpl implements FoodDao{
	
	@PersistenceContext
	private EntityManager em;
	
	@Transactional
	public void createFoodList(Food food) {
		
		em.persist(food);
	}
	
	@Transactional
	public List<Food> displayItems(){
		List<Food> listF=new ArrayList<Food>();
		Query query=em.createQuery("from Food");
		listF=query.getResultList();
		return listF;
		
	}

	@Transactional
	public void order(int item, int quantity) {
		Food f;
		f=em.find(Food.class, item);
		f.setQuantity(f.getQuantity()-1);
		OrderFood of=new OrderFood();
		of.setOfood(f.getfItem());
		of.setQuantity(quantity);
		of.setPrice(quantity*f.getCost());
		em.persist(of);
	}

	@Transactional
	public List<OrderFood> orderList() {
		List<OrderFood> orderL=new ArrayList<OrderFood>();
		Query query=em.createQuery("from OrderFood");
		orderL=query.getResultList();
		return orderL;
	}

	@Transactional
	public void deleteOrder(String oId[]) {
		
		for(String o:oId) {
			int id=Integer.parseInt(o);
			System.out.println(id);
			Query query=em.createQuery("delete from OrderFood where oId=:id");
			query.setParameter("id", id);
			query.executeUpdate();
			
		}
		
	}

	@Transactional
	public Food findCost(int fId) {
		Food f=em.find(Food.class, fId);
		return f;
		
	}

	


	

}
