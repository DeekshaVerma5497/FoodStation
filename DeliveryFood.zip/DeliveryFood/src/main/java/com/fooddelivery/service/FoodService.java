package com.fooddelivery.service;

import java.util.List;

import com.fooddelivery.model.Food;
import com.fooddelivery.model.OrderFood;

public interface FoodService {

	public void createFoodList();

	public List<Food> displayItems();

	public void order(int item, int quantity);

	public List<OrderFood> orderList();

	public void deleteOrder(String oId[]);

	public Food findCost(int fId);

}
