package com.fooddelivery.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.fooddelivery.model.Food;
import com.fooddelivery.service.FoodService;

@Controller
public class FoodController {

	@Autowired(required=true)
	private FoodService foodService;
	
	@RequestMapping("/")
	public String homePage(Model model) {
		//foodService.createFoodList();
		List<Food> foodL=foodService.displayItems();
		model.addAttribute("foodL",foodL);

		return "Welcome";
	}
	
	@RequestMapping(value="/menu")
	public String displayItems(Model model) {
		List<Food> foodL=foodService.displayItems();
		model.addAttribute("foodL",foodL);
		return "Order";
	}
	
	@RequestMapping(value="/order")
	public ModelAndView order(Model model, HttpServletRequest request, HttpServletResponse response) {
		int item=Integer.parseInt(request.getParameter("foodList"));
		int quantity=Integer.parseInt(request.getParameter("quantity"));
		System.out.println(item);
		foodService.order(item,quantity);
		return new ModelAndView("Thankyou");
	}
	
	
	
}
