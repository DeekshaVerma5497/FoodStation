package com.fooddelivery.dao;

import java.util.List;

import com.fooddelivery.model.Food;

public interface FoodDao {

	public void createFoodList(Food food);

	public List<Food> displayItems();

	public void order(int item, int quantity);
}
