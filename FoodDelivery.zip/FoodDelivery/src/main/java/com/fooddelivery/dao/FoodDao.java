package com.fooddelivery.dao;

import java.util.List;

import com.fooddelivery.model.Food;
import com.fooddelivery.model.OrderFood;

public interface FoodDao {

	public void createFoodList(Food food);

	public List<Food> displayItems();

	public void order(int item, int quantity);

	public List<OrderFood> orderList();
}
