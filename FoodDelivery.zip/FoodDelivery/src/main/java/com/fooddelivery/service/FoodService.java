package com.fooddelivery.service;

import java.util.List;

import com.fooddelivery.model.Food;

public interface FoodService {

	public void createFoodList();

	public List<Food> displayItems();

	public void order(int item, int quantity);

}
