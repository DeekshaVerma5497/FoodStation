package com.fooddelivery.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.fooddelivery.dao.FoodDao;
import com.fooddelivery.model.Food;
import com.fooddelivery.model.OrderFood;

@Service
@Qualifier("foodService")
public class FoodServiceImpl implements FoodService{
	
	@Autowired(required=true)
	private FoodDao foodDao;
	
	public void createFoodList() {
		Food food=new Food();
		food.setfItem("Chicken Khadai");
		food.setCost(180.0);
		food.setQuantity(10);
		foodDao.createFoodList(food);
		
		Food food2=new Food();
		food2.setfItem("Chicken Butter Masala");
		food2.setCost(210.0);
		food2.setQuantity(30);
		foodDao.createFoodList(food2);
		
		Food food3=new Food();
		food3.setfItem("Aloo Bhujiya");
		food3.setCost(10.0);
		food3.setQuantity(20);
		foodDao.createFoodList(food3);
		
		
	}
	
	public List<Food> displayItems() {
		return foodDao.displayItems();
	}

	
	public void order(int item, int quantity) {
		foodDao.order(item,quantity);
		
	}

	
	public List<OrderFood> orderList() {
		return foodDao.orderList();
	}

	

}
