package com.fooddelivery.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Food {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int fId;
	private
	String fItem;
	double cost;
	int quantity;
	public int getfId() {
		return fId;
	}
	public void setfId(int fId) {
		this.fId = fId;
	}
	public String getfItem() {
		return fItem;
	}
	public void setfItem(String fItem) {
		this.fItem = fItem;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Food(int fId, String fItem, double cost, int quantity) {
		super();
		this.fId = fId;
		this.fItem = fItem;
		this.cost = cost;
		this.quantity = quantity;
	}
	public Food() {
		
	}
	
	
	
}
