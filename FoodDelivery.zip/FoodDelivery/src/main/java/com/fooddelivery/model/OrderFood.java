package com.fooddelivery.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class OrderFood {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int oId;
	private
	String ofood;
	int Quantity;
	double price;
	
	public OrderFood() {
		// TODO Auto-generated constructor stub
	}

	public int getoId() {
		return oId;
	}

	public void setoId(int oId) {
		this.oId = oId;
	}

	public String getOfood() {
		return ofood;
	}

	public void setOfood(String ofood) {
		this.ofood = ofood;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
	
}
